package com.kaniwa.customdimensionportal;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class CustomDimensionPortalClient implements ClientModInitializer {
    private static KeyBinding teleportKey;

    @Override
    public void onInitializeClient() {
        teleportKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.custom_dimension_portal.teleport",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_G,
            KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (teleportKey.wasPressed()) {
                if (client.player != null && client.getNetworkHandler() != null) {
                    client.getNetworkHandler().sendChatCommand("cdp_teleport");
                }
            }
        });
    }
}
