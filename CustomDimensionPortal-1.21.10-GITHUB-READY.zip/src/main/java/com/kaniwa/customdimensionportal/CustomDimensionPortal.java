package com.kaniwa.customdimensionportal;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.Set;

public class CustomDimensionPortal implements ModInitializer {
    public static final String MOD_ID = "custom_dimension_portal";

    public static final Block PORTAL_BLOCK = Registry.register(
        Registries.BLOCK,
        Identifier.of(MOD_ID, "portal_block"),
        new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(1.5f))
    );

    public static final RegistryKey<World> VOID_REALM = RegistryKey.of(
        RegistryKeys.WORLD,
        Identifier.of(MOD_ID, "void_realm")
    );

    static {
        Registry.register(
            Registries.ITEM,
            Identifier.of(MOD_ID, "portal_block"),
            new BlockItem(PORTAL_BLOCK, new Item.Settings())
        );
    }

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(net.minecraft.server.command.CommandManager.literal("cdp_teleport")
                .requires(source -> source.getEntity() instanceof ServerPlayerEntity)
                .executes(context -> {
                    ServerPlayerEntity player = context.getSource().getPlayerOrThrow();
                    var server = context.getSource().getServer();

                    BlockHitResult hit = raycastBlock(player, 6.0);
                    BlockPos hitPos = hit.getBlockPos();
                    if (!player.getEntityWorld().getBlockState(hitPos).isOf(PORTAL_BLOCK)) {
                        return 0;
                    }

                    if (player.getEntityWorld().getRegistryKey().equals(VOID_REALM)) {
                        var overworld = server.getOverworld();
                        BlockPos spawn = overworld.getSpawnPos();
                        player.teleport(overworld, spawn.getX() + 0.5, spawn.getY() + 1.0,
                            spawn.getZ() + 0.5, Set.of(), player.getYaw(), player.getPitch(), false);
                        player.sendMessage(Text.literal("Returned to the Overworld."), true);
                    } else {
                        var target = server.getWorld(VOID_REALM);
                        if (target == null) {
                            context.getSource().sendError(Text.literal("Custom dimension is not loaded."));
                            return 0;
                        }
                        player.teleport(target, 0.5, 65.0, 0.5,
                            Set.of(), player.getYaw(), player.getPitch(), false);
                        player.sendMessage(Text.literal("Entered the Void Realm."), true);
                    }
                    return 1;
                }));
        });
    }

    private static BlockHitResult raycastBlock(ServerPlayerEntity player, double distance) {
        var start = player.getEyePos();
        var look = player.getRotationVec(1.0f);
        var end = start.add(look.multiply(distance));
        return player.getEntityWorld().raycast(new RaycastContext(
            start, end,
            RaycastContext.ShapeType.OUTLINE,
            RaycastContext.FluidHandling.NONE,
            player));
    }
}
